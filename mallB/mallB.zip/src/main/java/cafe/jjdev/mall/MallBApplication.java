package cafe.jjdev.mall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallBApplication {

	public static void main(String[] args) {
		SpringApplication.run(MallBApplication.class, args);
	}

}
