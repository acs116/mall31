package cafe.jjdev.mall.commons;

public class PathStr {
	public static final String UPLOAD_PATH = "D:\\AnChanSol\\sts-workspace\\mallB\\src\\main\\webapp\\upload";
}
